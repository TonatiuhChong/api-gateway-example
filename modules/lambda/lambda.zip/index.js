exports.handler = async (event) => {
  // ...your logic...
  return {
    message: "Lambda executed successfully ASO TEAM"
  };
};